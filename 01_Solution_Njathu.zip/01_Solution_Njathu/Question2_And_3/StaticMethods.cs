﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2_And_3
{
    public static class StaticMethods
    {
       
            // Question 2: Length of Longest Substring Without Repeating Characters
            public static int LengthOfLongestSubstring(string s)
            {
                int maxLength = 0;
                int left = 0;
                Dictionary<char, int> count = new Dictionary<char, int>();     // dictionary ,to manage and track character counts 

                for (int right = 0; right < s.Length; right++)
                {
                    char c = s[right];
                    if (!count.ContainsKey(c))
                    {
                        count[c] = 0;
                    }
                    count[c]++;

                    while (count[c] > 1)
                    {
                        char leftChar = s[left];
                        count[leftChar]--;
                        if (count[leftChar] == 0)
                        {
                            count.Remove(leftChar);
                        }
                        left++;
                    }
                    maxLength = Math.Max(maxLength, right - left + 1);
                }

                return maxLength;
            





          
              }

        /* Question 3: Word Ladder Length*/
        public static int LadderLength(string startWord, string endWord, IList<string> wordList)
        {
            // Pattern to all words e.g. h*t => hot, hit
            IDictionary<string, ISet<string>> patternToWordMap = new Dictionary<string, ISet<string>>(wordList.Count * startWord.Length);
            // Word to all patterns for the worrd e.g. hot => *ot, h*t, ho*
            IDictionary<string, ISet<string>> wordToPatternMap = new Dictionary<string, ISet<string>>(wordList.Count);

            void CachePatternToWord(string word)
            {
                if (!wordToPatternMap.ContainsKey(word))
                {
                    wordToPatternMap.Add(word, new HashSet<string>());
                }
                char[] wordArray = word.ToCharArray();
                for (int p = 0; p < word.Length; p++)
                {
                    char originalChar = wordArray[p];
                    wordArray[p] = '*';
                    string key = new string(wordArray);
                    wordToPatternMap[word].Add(key);

                    if (!patternToWordMap.ContainsKey(key))
                    {
                        patternToWordMap[key] = new HashSet<string>();
                    }
                    patternToWordMap[key].Add(word);
                    wordArray[p] = originalChar;
                }
            }

            // Generating Pattern to Word and Word to Pattrn mappings
            CachePatternToWord(startWord);
            foreach (var word in wordList)
            {
                CachePatternToWord(word);
            }

            // BFS setup,BFS best optiono for thiss problem for mantaining perfomance
            Queue<string> queue = new Queue<string>();
            HashSet<string> visited = new HashSet<string>();
            queue.Enqueue(startWord);
            visited.Add(startWord);
            int pathLength = 0;

            while (queue.Count > 0)
            {
                int levelSize = queue.Count;
                pathLength++;
                for (int i = 0; i < levelSize; i++)
                {
                    string currentWord = queue.Dequeue();
                    if (currentWord == endWord)
                    {
                        return pathLength;
                    }

                    foreach (string pattern in wordToPatternMap[currentWord])
                    {
                        if (patternToWordMap.ContainsKey(pattern))
                        {
                            foreach (string neighbor in patternToWordMap[pattern])
                            {
                                if (!visited.Contains(neighbor))
                                {
                                    visited.Add(neighbor);
                                    queue.Enqueue(neighbor);
                                }
                            }
                        }
                    }
                }
            }

            return 0;
        }
    }
}

