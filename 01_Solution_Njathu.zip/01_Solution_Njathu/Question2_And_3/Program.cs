﻿/** See https://aka.ms/new-console-template for more information
using Question2_And_3;

Console.WriteLine("Hello, World!");

int lengthOfSubstring = StaticMethods.LengthOfLongestSubstring("");
int ladderLength = StaticMethods.LadderLength("", "", new List<string>());

Console.WriteLine("Longest Substring: ", lengthOfSubstring);
Console.WriteLine("Ladder Length: ", ladderLength); */




/*time complexity: O(n)

the solution efficiently finds the length of the longest substring without repeating characters 
in linear time relative to the length of the input strin ,using sliding window approsach*/


using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Question2_And_3
{
    

    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            // Question 2: Length of Longest Substring Without Repeating Characters
            string testString1 = "abcabcbb";
            string testString2 = "bbbbb";
            string testString3 = "pwwkew";

            int expectedLength1 = 3; // For "abcabcbb"
            int expectedLength2 = 1; // For "bbbbb"
            int expectedLength3 = 3; // For "pwwkew"

            int lengthOfSubstring1 = StaticMethods.LengthOfLongestSubstring(testString1);
            int lengthOfSubstring2 = StaticMethods.LengthOfLongestSubstring(testString2);
            int lengthOfSubstring3 = StaticMethods.LengthOfLongestSubstring(testString3);

            Debug.Assert(lengthOfSubstring1 == expectedLength1);
            Debug.Assert(lengthOfSubstring2 == expectedLength2);
            Debug.Assert(lengthOfSubstring3 == expectedLength3);

            Console.WriteLine($"Longest Substring of '{testString1}': {lengthOfSubstring1}");
            Console.WriteLine($"Longest Substring of '{testString2}': {lengthOfSubstring2}");
            Console.WriteLine($"Longest Substring of '{testString3}': {lengthOfSubstring3}");

            // Question 3: Word Ladder Length
            string beginWord = "hit";
            string endWord = "cog";
            List<string> wordList1 = new List<string> { "hot", "dot", "dog", "lot", "log", "cog" };
            List<string> wordList2 = new List<string> { "hot", "dot", "dog", "lot", "log" };

            int expectedLadderLength1 = 5; // For wordList1
            int expectedLadderLength2 = 0; // For wordList2

            int ladderLength1 = StaticMethods.LadderLength(beginWord, endWord, wordList1);
            int ladderLength2 = StaticMethods.LadderLength(beginWord, endWord, wordList2);

            Debug.Assert(ladderLength1 == expectedLadderLength1);
            Debug.Assert(ladderLength2 == expectedLadderLength2);

            Console.WriteLine($"Length of ladder from '{beginWord}' to '{endWord}' (wordList1): {ladderLength1}");
            Console.WriteLine($"Length of ladder from '{beginWord}' to '{endWord}' (wordList2): {ladderLength2}");

            Console.ReadKey();
        }
    }
}