﻿/*A simple role-playing game in C#. The game involves two types of
characters: Warrior and Mage. Each character has a name, health points (HP), and an attack method.
The Warrior has a special ability called Slash, and the Mage has a special ability called Fireball.*/



/*Solution optimized  : constant time and space complexity, O(1) */


using System;

namespace RPGGame
{
    public abstract class Character
    {
        public string Name { get; }
        public int Health { get; private set; }

        protected Character(string name)
        {
            Name = name;
            Health = 50; // 50 hp at the start of esch character.
        }

        /* methods Attack and TakeDamage */

        public void Attack(Character target)
        {
            try
            {
                if (target == null)
                {
                    throw new ArgumentNullException(nameof(target), "Target character cannot be null.");
                }

                // Each attack reduces health points by 10.
                target.TakeDamage(10);
                Console.WriteLine($"{target.Name} takes 10 damage, {target.Health} HP remaining");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        public void TakeDamage(int damage)
        {
            try
            {
                if (damage < 0)
                {
                    throw new ArgumentException("Damage value cannot be negative.");
                }

                Health = Math.Max(0, Health - damage); // Health points must be >=0, always.
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        public abstract void SpecialAbility(Character target); // Abstract method fo Warrior and Mage.
    }



    // Mage class inheriting from Character class
    public class Mage : Character
    {
        public Mage(string name) : base(name) { }

        public override void SpecialAbility(Character target)
        {
            try
            {
                if (target == null)
                {
                    throw new ArgumentNullException(nameof(target), "Target character cannot be null.");
                }

                // Fireball ability reduces health points by 20.
                target.TakeDamage(20);
                Console.WriteLine($"{target.Name} takes 20 damage from Fireball, {target.Health} HP remaining");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }

    public class Warrior : Character
    {
        public Warrior(string name) : base(name) { }

        public override void SpecialAbility(Character target)
        {
            try
            {
                if (target == null)
                {
                    throw new ArgumentNullException(nameof(target), "Target character cannot be null.");
                }

                // The Slash ability reduces health points by 15.
                target.TakeDamage(15);
                Console.WriteLine($"{target.Name} takes 15 damage from Slash, {target.Health} HP remaining");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }

    public class Program
    {
        private static void Main(string[] args)
        {
            try
            {
                // Create Characters
                Character warrior = new Warrior("Warrior");
                Character mage = new Mage("Mage");

                // Battle Simulation
                warrior.Attack(mage);
                mage.Attack(warrior);
                warrior.SpecialAbility(mage);
                mage.SpecialAbility(warrior);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                Console.ReadKey();
            }
        }
    }
}
